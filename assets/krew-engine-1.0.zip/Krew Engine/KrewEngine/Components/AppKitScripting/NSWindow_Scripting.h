//
//  NSWindow_Scripting.h
//  KrewEngine
//
//  Created by Diego Revilla Rubiera on 03/09/2018.
//  Copyright © 2018 SKG. All rights reserved.
//

#ifndef NSWindow_Scripting_h
#define NSWindow_Scripting_h

#import <AppKit/NSWindowScripting.h>

#endif /* NSWindow_Scripting_h */
