//
//  SFNTLayoutTypes.h
//  KrewEngine
//
//  Created by Diego Revilla Rubiera on 05/09/2018.
//  Copyright © 2018 SKG. All rights reserved.
//

#ifndef SFNTLayoutTypes_h
#define SFNTLayoutTypes_h

#include <CoreText/SFNTLayoutTypes.h>

#endif /* SFNTLayoutTypes_h */
