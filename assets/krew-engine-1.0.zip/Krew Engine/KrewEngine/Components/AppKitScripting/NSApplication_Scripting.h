//
//  NSApplication_Scripting.h
//  KrewEngine
//
//  Created by Diego Revilla Rubiera on 03/09/2018.
//  Copyright © 2018 SKG. All rights reserved.
//

#ifndef NSApplication_Scripting_h
#define NSApplication_Scripting_h

#import <AppKit/NSApplicationScripting.h>

#endif /* NSApplication_Scripting_h */
