//
//  ATSUnicodeDrawing.h
//  KrewEngine
//
//  Created by Diego Revilla Rubiera on 19/09/2018.
//  Copyright © 2018 SKG. All rights reserved.
//

#ifndef ATSUnicodeDrawing_h
#define ATSUnicodeDrawing_h

#ifndef __ATSUNICODETYPES__
#include <QD/ATSUnicodeTypes.h>
#endif

#endif /* ATSUnicodeDrawing_h */
