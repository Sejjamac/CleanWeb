//
//  NSTextStorage_TextSuite.h
//  KrewEngine
//
//  Created by Diego Revilla Rubiera on 03/09/2018.
//  Copyright © 2018 SKG. All rights reserved.
//

#ifndef NSTextStorage_TextSuite_h
#define NSTextStorage_TextSuite_h

#import <AppKit/NSTextStorageScripting.h>

#endif /* NSTextStorage_TextSuite_h */
