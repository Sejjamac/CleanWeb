//
//  AppKitScripting.h
//  KrewEngine
//
//  Created by Diego Revilla Rubiera on 03/09/2018.
//  Copyright © 2018 SKG. All rights reserved.
//

#ifndef AppKitScripting_h
#define AppKitScripting_h

#import <AppKit/AppKit.h>

// There are some compatibility headers in the vestigial Scripting framework though.
#import <Scripting/Scripting.h>

#endif /* AppKitScripting_h */
