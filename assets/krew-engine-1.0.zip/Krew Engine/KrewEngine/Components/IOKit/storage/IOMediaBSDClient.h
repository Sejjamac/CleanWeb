//
//  IOMediaBSDClient.h
//  KrewEngine
//
//  Created by Diego Revilla Rubiera on 18/08/2018.
//  Copyright © 2018 SKG. All rights reserved.
//

#ifndef IOMediaBSDClient_h
#define IOMediaBSDClient_h

#ifndef _IOMEDIABSDCLIENT_H
#define _IOMEDIABSDCLIENT_H

#include <sys/disk.h>

#endif /* !_IOMEDIABSDCLIENT_H */

#endif /* IOMediaBSDClient_h */
