//
//  ft2build.h
//  KrewEngine
//
//  Created by Diego Revilla Rubiera on 05/09/2018.
//  Copyright © 2018 SKG. All rights reserved.
//

#ifndef ft2build_h
#define ft2build_h

#ifndef FT2BUILD_H_
#define FT2BUILD_H_

#include "freetype/config/ftheader.h"

#endif /* FT2BUILD_H_ */

#endif /* ft2build_h */
