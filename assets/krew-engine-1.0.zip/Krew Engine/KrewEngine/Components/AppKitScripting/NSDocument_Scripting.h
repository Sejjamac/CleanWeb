//
//  NSDocument_Scripting.h
//  KrewEngine
//
//  Created by Diego Revilla Rubiera on 03/09/2018.
//  Copyright © 2018 SKG. All rights reserved.
//

#ifndef NSDocument_Scripting_h
#define NSDocument_Scripting_h

#import <AppKit/NSDocumentScripting.h>

#endif /* NSDocument_Scripting_h */
