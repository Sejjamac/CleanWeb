//
//  ATSUnicodeObjects.h
//  KrewEngine
//
//  Created by Diego Revilla Rubiera on 19/09/2018.
//  Copyright © 2018 SKG. All rights reserved.
//

#ifndef ATSUnicodeObjects_h
#define ATSUnicodeObjects_h

#ifndef __ATSUNICODETYPES__
#include <QD/ATSUnicodeTypes.h>
#endif

#endif /* ATSUnicodeObjects_h */
